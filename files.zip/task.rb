class Task < ApplicationRecord
  belongs_to :user

  attribute :status, :string, default: 'pending'

  enum :status, {
    status_pending: 'pending',
    status_in_progress: 'in_progress',
    status_completed: 'completed'
  }, prefix: :status

  validates :title, presence: true, length: { maximum: 200 }
  validates :status, presence: true, inclusion: { in: %w[pending in_progress completed] }
  validate :due_date_cannot_be_in_the_past

  before_save :trim_title

  private

  def trim_title
    self.title = title.strip if title.present?
  end

  def due_date_cannot_be_in_the_past
    if due_date.present? && due_date < Time.current
      errors.add(:due_date, "can't be in the past")
    end
  end
end
