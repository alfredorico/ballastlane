# Task Management API

A RESTful API built with Rails 7.1 and PostgreSQL for managing tasks with JWT authentication.

## Features

- **User Authentication**: JWT-based authentication with access and refresh tokens
- **Task Management**: Full CRUD operations for tasks
- **Authorization**: Users can only access their own tasks
- **API Versioning**: All endpoints versioned under `/api/v1`
- **JSON API Format**: Responses follow JSON API specification
- **Comprehensive Testing**: RSpec tests for models and request specs

## Requirements

- Ruby 3.2.0
- Rails 7.1.x
- PostgreSQL 12+

## Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd task_management_api
   ```

2. **Install dependencies**
   ```bash
   bundle install
   ```

3. **Setup database**
   ```bash
   rails db:create
   rails db:migrate
   ```

4. **Run tests**
   ```bash
   bundle exec rspec
   ```

5. **Start the server**
   ```bash
   rails server
   ```

## API Endpoints

### Authentication

#### Sign Up
```http
POST /api/v1/auth/signup
Content-Type: application/json

{
  "email": "user@example.com",
  "password": "password123",
  "password_confirmation": "password123",
  "name": "John Doe"
}
```

**Response (201 Created):**
```json
{
  "message": "User created successfully",
  "user": {
    "id": 1,
    "email": "user@example.com",
    "name": "John Doe"
  },
  "access_token": "eyJhbGciOiJIUzI1NiJ9...",
  "refresh_token": "abc123..."
}
```

#### Login
```http
POST /api/v1/auth/login
Content-Type: application/json

{
  "email": "user@example.com",
  "password": "password123"
}
```

**Response (200 OK):**
```json
{
  "message": "Login successful",
  "user": {
    "id": 1,
    "email": "user@example.com",
    "name": "John Doe"
  },
  "access_token": "eyJhbGciOiJIUzI1NiJ9...",
  "refresh_token": "abc123..."
}
```

#### Refresh Token
```http
POST /api/v1/auth/refresh
Content-Type: application/json

{
  "refresh_token": "abc123..."
}
```

**Response (200 OK):**
```json
{
  "access_token": "eyJhbGciOiJIUzI1NiJ9..."
}
```

#### Logout
```http
DELETE /api/v1/auth/logout
Content-Type: application/json

{
  "refresh_token": "abc123..."
}
```

**Response (200 OK):**
```json
{
  "message": "Logged out successfully"
}
```

### Tasks (All require Authentication)

**Note**: All task endpoints require the `Authorization` header:
```
Authorization: Bearer <access_token>
```

#### Get All Tasks
```http
GET /api/v1/tasks
Authorization: Bearer <access_token>
```

**Response (200 OK):**
```json
{
  "data": [
    {
      "id": "1",
      "type": "task",
      "attributes": {
        "title": "Complete project",
        "description": "Finish the API implementation",
        "status": "pending",
        "due_date": "2024-12-31T10:00:00.000Z",
        "created_at": "2024-01-15T10:00:00.000Z",
        "updated_at": "2024-01-15T10:00:00.000Z"
      },
      "relationships": {
        "user": {
          "data": {
            "id": "1",
            "type": "user"
          }
        }
      }
    }
  ]
}
```

#### Get Single Task
```http
GET /api/v1/tasks/:id
Authorization: Bearer <access_token>
```

**Response (200 OK):**
```json
{
  "data": {
    "id": "1",
    "type": "task",
    "attributes": {
      "title": "Complete project",
      "description": "Finish the API implementation",
      "status": "pending",
      "due_date": "2024-12-31T10:00:00.000Z",
      "created_at": "2024-01-15T10:00:00.000Z",
      "updated_at": "2024-01-15T10:00:00.000Z"
    },
    "relationships": {
      "user": {
        "data": {
          "id": "1",
          "type": "user"
        }
      }
    }
  }
}
```

#### Create Task
```http
POST /api/v1/tasks
Authorization: Bearer <access_token>
Content-Type: application/json

{
  "task": {
    "title": "New Task",
    "description": "Task description",
    "status": "pending",
    "due_date": "2024-12-31T10:00:00.000Z"
  }
}
```

**Response (201 Created):**
```json
{
  "data": {
    "id": "2",
    "type": "task",
    "attributes": {
      "title": "New Task",
      "description": "Task description",
      "status": "pending",
      "due_date": "2024-12-31T10:00:00.000Z",
      "created_at": "2024-01-15T11:00:00.000Z",
      "updated_at": "2024-01-15T11:00:00.000Z"
    }
  }
}
```

#### Update Task
```http
PATCH /api/v1/tasks/:id
Authorization: Bearer <access_token>
Content-Type: application/json

{
  "task": {
    "title": "Updated Task",
    "status": "completed"
  }
}
```

**Response (200 OK):**
```json
{
  "data": {
    "id": "1",
    "type": "task",
    "attributes": {
      "title": "Updated Task",
      "description": "Task description",
      "status": "completed",
      "due_date": "2024-12-31T10:00:00.000Z",
      "created_at": "2024-01-15T10:00:00.000Z",
      "updated_at": "2024-01-15T12:00:00.000Z"
    }
  }
}
```

#### Delete Task
```http
DELETE /api/v1/tasks/:id
Authorization: Bearer <access_token>
```

**Response (204 No Content)**

### Error Responses

#### Unauthorized (401)
```json
{
  "error": "Unauthorized"
}
```

#### Not Found (404)
```json
{
  "error": "Task not found"
}
```

#### Unprocessable Entity (422)
```json
{
  "errors": [
    "Title can't be blank",
    "Due date can't be in the past"
  ]
}
```

## Task Model

### Attributes
- `title` (string, required, max 200 characters) - Automatically trimmed
- `description` (text, optional)
- `status` (enum: pending, in_progress, completed) - Defaults to 'pending'
- `due_date` (datetime) - Must be in the future
- `user_id` (foreign key)

### Status Enum Methods
The status enum includes prefixed methods to avoid collision:
- `status_pending?`
- `status_in_progress?`
- `status_completed?`

## Authentication

- **Access Token**: Short-lived (15 minutes), used for API requests
- **Refresh Token**: Long-lived (7 days), used to obtain new access tokens
- Access tokens must be included in the `Authorization` header as: `Bearer <token>`

## Running Tests

```bash
# Run all tests
bundle exec rspec

# Run specific test file
bundle exec rspec spec/models/task_spec.rb

# Run with coverage
bundle exec rspec --format documentation
```

## Project Structure

```
task_management_api/
├── app/
│   ├── controllers/
│   │   ├── application_controller.rb
│   │   └── api/
│   │       └── v1/
│   │           ├── authentication_controller.rb
│   │           └── tasks_controller.rb
│   ├── models/
│   │   ├── user.rb
│   │   ├── task.rb
│   │   └── refresh_token.rb
│   ├── serializers/
│   │   └── task_serializer.rb
│   └── services/
│       └── json_web_token.rb
├── config/
│   ├── database.yml
│   ├── routes.rb
│   └── initializers/
│       └── cors.rb
├── db/
│   └── migrate/
│       ├── 20240101000001_create_users.rb
│       ├── 20240101000002_create_refresh_tokens.rb
│       └── 20240101000003_create_tasks.rb
└── spec/
    ├── factories/
    │   ├── users.rb
    │   └── tasks.rb
    ├── models/
    │   └── task_spec.rb
    ├── requests/
    │   └── api/
    │       └── v1/
    │           └── tasks_spec.rb
    └── support/
        ├── factory_bot.rb
        └── authentication_helper.rb
```

## Important Notes

1. **Security**: In production, make sure to:
   - Set a strong `SECRET_KEY_BASE` in credentials
   - Configure CORS to allow only specific domains
   - Use HTTPS for all API communication
   - Set appropriate token expiration times

2. **Database**: The migrations include:
   - Foreign key constraints for data integrity
   - Indexes on `user_id` for better query performance
   - Unique constraints on user email and refresh tokens

3. **Testing**: The test suite includes:
   - Model specs for validations and associations
   - Request specs for authentication and CRUD operations
   - Tests for both authenticated and unauthenticated access
   - Factory definitions for easy test data creation

4. **Token Management**:
   - Access tokens expire in 15 minutes
   - Refresh tokens expire in 7 days
   - On logout, refresh tokens are destroyed
   - Each login creates a new refresh token

## License

This project is available as open source under the terms of the MIT License.
