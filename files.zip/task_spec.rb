require 'rails_helper'

RSpec.describe Task, type: :model do
  describe 'associations' do
    it { should belong_to(:user) }
  end

  describe 'validations' do
    it { should validate_presence_of(:title) }
    it { should validate_length_of(:title).is_at_most(200) }
    it { should validate_presence_of(:status) }
    it { should validate_inclusion_of(:status).in_array(%w[pending in_progress completed]) }

    context 'due_date validation' do
      let(:user) { create(:user) }

      it 'is valid with a future due_date' do
        task = build(:task, user: user, due_date: 1.day.from_now)
        expect(task).to be_valid
      end

      it 'is invalid with a past due_date' do
        task = build(:task, user: user, due_date: 1.day.ago)
        expect(task).not_to be_valid
        expect(task.errors[:due_date]).to include("can't be in the past")
      end

      it 'is valid without a due_date' do
        task = build(:task, user: user, due_date: nil)
        expect(task).to be_valid
      end
    end
  end

  describe 'enums' do
    it 'defines status enum with prefix' do
      task = create(:task)
      
      expect(task).to respond_to(:status_pending?)
      expect(task).to respond_to(:status_in_progress?)
      expect(task).to respond_to(:status_completed?)
    end

    it 'defaults to pending status' do
      task = Task.new(title: 'Test', user: create(:user))
      expect(task.status).to eq('pending')
    end
  end

  describe 'callbacks' do
    context 'before_save :trim_title' do
      let(:user) { create(:user) }

      it 'trims whitespace from title' do
        task = create(:task, user: user, title: '  Test Title  ')
        expect(task.title).to eq('Test Title')
      end

      it 'does not modify title without extra whitespace' do
        task = create(:task, user: user, title: 'Test Title')
        expect(task.title).to eq('Test Title')
      end
    end
  end

  describe 'attribute defaults' do
    it 'sets status to pending by default' do
      task = Task.new
      expect(task.status).to eq('pending')
    end
  end
end
