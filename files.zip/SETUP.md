# Setup Instructions

## Prerequisites
- Ruby 3.2.0 (use rbenv or rvm to install)
- PostgreSQL 12+ installed and running
- Bundler gem installed

## Step-by-Step Setup

### 1. Install Ruby Dependencies
```bash
bundle install
```

### 2. Configure Database
Make sure PostgreSQL is running, then:

```bash
# Create databases
rails db:create

# Run migrations
rails db:migrate

# For test environment
RAILS_ENV=test rails db:migrate
```

### 3. Generate Secret Key (Production)
```bash
# Generate a new secret key
rails secret

# Add it to your credentials (for production)
EDITOR="nano" rails credentials:edit
```

### 4. Run Tests
```bash
# Run all tests
bundle exec rspec

# Run with documentation format
bundle exec rspec --format documentation

# Run specific test
bundle exec rspec spec/models/task_spec.rb
```

### 5. Start the Server
```bash
# Development server
rails server

# Or specify port
rails server -p 3000
```

The API will be available at `http://localhost:3000`

## Testing the API

### Using cURL

**Sign Up:**
```bash
curl -X POST http://localhost:3000/api/v1/auth/signup \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@example.com",
    "password": "password123",
    "password_confirmation": "password123",
    "name": "Test User"
  }'
```

**Login:**
```bash
curl -X POST http://localhost:3000/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@example.com",
    "password": "password123"
  }'
```

**Create Task (replace TOKEN with your access token):**
```bash
curl -X POST http://localhost:3000/api/v1/tasks \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer TOKEN" \
  -d '{
    "task": {
      "title": "My First Task",
      "description": "This is a test task",
      "status": "pending",
      "due_date": "2024-12-31T10:00:00Z"
    }
  }'
```

**Get All Tasks:**
```bash
curl -X GET http://localhost:3000/api/v1/tasks \
  -H "Authorization: Bearer TOKEN"
```

### Using Postman or Insomnia

1. Import the base URL: `http://localhost:3000`
2. Create a new request collection for the API
3. For authentication endpoints, no headers needed
4. For task endpoints, add header: `Authorization: Bearer <your_token>`

## Troubleshooting

### Database Connection Issues
- Ensure PostgreSQL is running: `pg_ctl status`
- Check your database.yml configuration
- Verify PostgreSQL user permissions

### Migration Errors
```bash
# Reset database (WARNING: destroys all data)
rails db:drop db:create db:migrate
```

### Test Failures
```bash
# Clean test database
RAILS_ENV=test rails db:reset
bundle exec rspec
```

### JWT Secret Key Issues
- Make sure SECRET_KEY_BASE is set in your environment
- For development, Rails generates this automatically
- For production, use `rails credentials:edit`

## Environment Variables (Optional)

Create a `.env` file in the root directory:

```env
DATABASE_URL=postgresql://username:password@localhost/task_management_api_development
SECRET_KEY_BASE=your_secret_key_here
RAILS_MAX_THREADS=5
```

## Additional Commands

```bash
# Check routes
rails routes

# Open Rails console
rails console

# Check code style (if using rubocop)
rubocop

# Database rollback
rails db:rollback

# Seed database (if you create seeds)
rails db:seed
```

## Production Deployment Notes

Before deploying to production:

1. Set environment variables:
   - `SECRET_KEY_BASE`
   - `DATABASE_URL`
   - `RAILS_ENV=production`

2. Update CORS settings in `config/initializers/cors.rb`

3. Precompile assets (if using any):
   ```bash
   RAILS_ENV=production rails assets:precompile
   ```

4. Run migrations:
   ```bash
   RAILS_ENV=production rails db:migrate
   ```

5. Consider using a process manager like systemd or Foreman

6. Set up a reverse proxy (nginx/Apache) in front of Puma

7. Configure SSL/TLS certificates
