Rails.application.routes.draw do
  namespace :api do
    namespace :v1 do
      # Authentication routes
      post 'auth/signup', to: 'authentication#signup'
      post 'auth/login', to: 'authentication#login'
      delete 'auth/logout', to: 'authentication#logout'
      post 'auth/refresh', to: 'authentication#refresh'

      # Task routes
      resources :tasks
    end
  end
end
