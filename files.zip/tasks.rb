FactoryBot.define do
  factory :task do
    title { Faker::Lorem.sentence(word_count: 3) }
    description { Faker::Lorem.paragraph }
    status { 'pending' }
    due_date { 1.week.from_now }
    association :user

    trait :in_progress do
      status { 'in_progress' }
    end

    trait :completed do
      status { 'completed' }
    end

    trait :with_past_due_date do
      due_date { 1.day.ago }
    end
  end
end
