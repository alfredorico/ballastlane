class TaskSerializer
  include JSONAPI::Serializer

  attributes :title, :description, :status, :due_date, :created_at, :updated_at

  belongs_to :user
end
