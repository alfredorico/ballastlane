require 'rails_helper'

RSpec.describe 'Api::V1::Tasks', type: :request do
  let(:user) { create(:user) }
  let(:other_user) { create(:user) }
  let!(:tasks) { create_list(:task, 3, user: user) }
  let(:task) { tasks.first }
  let(:valid_attributes) do
    {
      task: {
        title: 'New Task',
        description: 'Task description',
        status: 'pending',
        due_date: 1.week.from_now
      }
    }
  end
  let(:invalid_attributes) do
    {
      task: {
        title: '',
        status: 'invalid_status'
      }
    }
  end

  describe 'GET /api/v1/tasks' do
    context 'when authenticated' do
      it 'returns all tasks for the current user' do
        get '/api/v1/tasks', headers: auth_headers(user)

        expect(response).to have_http_status(:ok)
        json_response = JSON.parse(response.body)
        expect(json_response['data'].length).to eq(3)
      end

      it 'does not return tasks from other users' do
        create(:task, user: other_user)
        get '/api/v1/tasks', headers: auth_headers(user)

        json_response = JSON.parse(response.body)
        expect(json_response['data'].length).to eq(3)
      end
    end

    context 'when not authenticated' do
      it 'returns unauthorized status' do
        get '/api/v1/tasks'

        expect(response).to have_http_status(:unauthorized)
        json_response = JSON.parse(response.body)
        expect(json_response['error']).to eq('Unauthorized')
      end
    end
  end

  describe 'GET /api/v1/tasks/:id' do
    context 'when authenticated' do
      it 'returns the task' do
        get "/api/v1/tasks/#{task.id}", headers: auth_headers(user)

        expect(response).to have_http_status(:ok)
        json_response = JSON.parse(response.body)
        expect(json_response['data']['id']).to eq(task.id.to_s)
        expect(json_response['data']['attributes']['title']).to eq(task.title)
      end

      it 'returns not found for non-existent task' do
        get '/api/v1/tasks/99999', headers: auth_headers(user)

        expect(response).to have_http_status(:not_found)
        json_response = JSON.parse(response.body)
        expect(json_response['error']).to eq('Task not found')
      end

      it 'returns not found when trying to access another user\'s task' do
        other_task = create(:task, user: other_user)
        get "/api/v1/tasks/#{other_task.id}", headers: auth_headers(user)

        expect(response).to have_http_status(:not_found)
      end
    end

    context 'when not authenticated' do
      it 'returns unauthorized status' do
        get "/api/v1/tasks/#{task.id}"

        expect(response).to have_http_status(:unauthorized)
      end
    end
  end

  describe 'POST /api/v1/tasks' do
    context 'when authenticated' do
      context 'with valid parameters' do
        it 'creates a new task' do
          expect {
            post '/api/v1/tasks', params: valid_attributes, headers: auth_headers(user)
          }.to change(Task, :count).by(1)

          expect(response).to have_http_status(:created)
          json_response = JSON.parse(response.body)
          expect(json_response['data']['attributes']['title']).to eq('New Task')
        end

        it 'associates the task with the current user' do
          post '/api/v1/tasks', params: valid_attributes, headers: auth_headers(user)

          created_task = Task.last
          expect(created_task.user).to eq(user)
        end
      end

      context 'with invalid parameters' do
        it 'does not create a new task' do
          expect {
            post '/api/v1/tasks', params: invalid_attributes, headers: auth_headers(user)
          }.not_to change(Task, :count)

          expect(response).to have_http_status(:unprocessable_entity)
        end

        it 'returns error messages' do
          post '/api/v1/tasks', params: invalid_attributes, headers: auth_headers(user)

          json_response = JSON.parse(response.body)
          expect(json_response['errors']).to be_present
        end
      end

      context 'with past due_date' do
        it 'does not create a task' do
          past_date_attributes = {
            task: {
              title: 'Task with past date',
              due_date: 1.day.ago
            }
          }

          post '/api/v1/tasks', params: past_date_attributes, headers: auth_headers(user)

          expect(response).to have_http_status(:unprocessable_entity)
          json_response = JSON.parse(response.body)
          expect(json_response['errors']).to include("Due date can't be in the past")
        end
      end
    end

    context 'when not authenticated' do
      it 'returns unauthorized status' do
        post '/api/v1/tasks', params: valid_attributes

        expect(response).to have_http_status(:unauthorized)
      end
    end
  end

  describe 'PATCH/PUT /api/v1/tasks/:id' do
    let(:new_attributes) do
      {
        task: {
          title: 'Updated Task',
          status: 'completed'
        }
      }
    end

    context 'when authenticated' do
      context 'with valid parameters' do
        it 'updates the task' do
          patch "/api/v1/tasks/#{task.id}", params: new_attributes, headers: auth_headers(user)

          expect(response).to have_http_status(:ok)
          task.reload
          expect(task.title).to eq('Updated Task')
          expect(task.status).to eq('completed')
        end
      end

      context 'with invalid parameters' do
        it 'does not update the task' do
          patch "/api/v1/tasks/#{task.id}", params: invalid_attributes, headers: auth_headers(user)

          expect(response).to have_http_status(:unprocessable_entity)
          task.reload
          expect(task.title).not_to eq('')
        end
      end

      it 'cannot update another user\'s task' do
        other_task = create(:task, user: other_user)
        patch "/api/v1/tasks/#{other_task.id}", params: new_attributes, headers: auth_headers(user)

        expect(response).to have_http_status(:not_found)
      end
    end

    context 'when not authenticated' do
      it 'returns unauthorized status' do
        patch "/api/v1/tasks/#{task.id}", params: new_attributes

        expect(response).to have_http_status(:unauthorized)
      end
    end
  end

  describe 'DELETE /api/v1/tasks/:id' do
    context 'when authenticated' do
      it 'destroys the task' do
        expect {
          delete "/api/v1/tasks/#{task.id}", headers: auth_headers(user)
        }.to change(Task, :count).by(-1)

        expect(response).to have_http_status(:no_content)
      end

      it 'cannot delete another user\'s task' do
        other_task = create(:task, user: other_user)
        
        expect {
          delete "/api/v1/tasks/#{other_task.id}", headers: auth_headers(user)
        }.not_to change(Task, :count)

        expect(response).to have_http_status(:not_found)
      end
    end

    context 'when not authenticated' do
      it 'returns unauthorized status' do
        delete "/api/v1/tasks/#{task.id}"

        expect(response).to have_http_status(:unauthorized)
      end
    end
  end

  describe 'JSON API format' do
    it 'returns data in JSON API format' do
      get '/api/v1/tasks', headers: auth_headers(user)

      json_response = JSON.parse(response.body)
      expect(json_response).to have_key('data')
      expect(json_response['data']).to be_an(Array)
      
      first_task = json_response['data'].first
      expect(first_task).to have_key('id')
      expect(first_task).to have_key('type')
      expect(first_task).to have_key('attributes')
      expect(first_task['type']).to eq('task')
    end
  end
end
