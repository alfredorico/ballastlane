module Api
  module V1
    class AuthenticationController < ActionController::API
      skip_before_action :authenticate_request, if: -> { false }

      # POST /api/v1/auth/signup
      def signup
        user = User.new(user_params)

        if user.save
          access_token = JsonWebToken.encode(user_id: user.id)
          refresh_token = user.refresh_tokens.create!

          render json: {
            message: 'User created successfully',
            user: { id: user.id, email: user.email, name: user.name },
            access_token: access_token,
            refresh_token: refresh_token.token
          }, status: :created
        else
          render json: { errors: user.errors.full_messages }, status: :unprocessable_entity
        end
      end

      # POST /api/v1/auth/login
      def login
        user = User.find_by(email: params[:email])

        if user&.authenticate(params[:password])
          access_token = JsonWebToken.encode(user_id: user.id)
          refresh_token = user.refresh_tokens.create!

          render json: {
            message: 'Login successful',
            user: { id: user.id, email: user.email, name: user.name },
            access_token: access_token,
            refresh_token: refresh_token.token
          }, status: :ok
        else
          render json: { error: 'Invalid email or password' }, status: :unauthorized
        end
      end

      # DELETE /api/v1/auth/logout
      def logout
        token = params[:refresh_token]
        refresh_token = RefreshToken.find_by(token: token)

        if refresh_token
          refresh_token.destroy
          render json: { message: 'Logged out successfully' }, status: :ok
        else
          render json: { error: 'Invalid refresh token' }, status: :unprocessable_entity
        end
      end

      # POST /api/v1/auth/refresh
      def refresh
        token = params[:refresh_token]
        refresh_token = RefreshToken.active.find_by(token: token)

        if refresh_token && !refresh_token.expired?
          access_token = JsonWebToken.encode(user_id: refresh_token.user_id)
          render json: { access_token: access_token }, status: :ok
        else
          render json: { error: 'Invalid or expired refresh token' }, status: :unauthorized
        end
      end

      private

      def user_params
        params.permit(:email, :password, :password_confirmation, :name)
      end
    end
  end
end
